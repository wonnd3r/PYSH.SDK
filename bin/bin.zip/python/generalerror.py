import tkinter as tk
from tkinter import messagebox
root = tk.Tk()
root.withdraw()
messagebox.showinfo("ERROR! PYSH.SDK", "Something went wrong!")
root.quit()
