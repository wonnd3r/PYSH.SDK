import os
import shutil
import time
import subprocess
# Version v0.0.1
clear = lambda: os.system('clear')
clear()
SDK_COMPRESSED_DIRECTORY = os.getenv("SDK_COMPRESSED_DIRECTORY", os.path.join(os.getenv("HOME"), "pysh-v0.0.1", "sdk"))
SDK_DIRECTORY = os.getenv("SDK_DIRECTORY", os.path.join(os.getenv("HOME"), "pysh-v0.0.1"))
print(" ______   __  __     ______     __  __     ______     _____     __  __")
print("/\\  ==  \\/\\ \\_\\ \\   /\\  ___\\   /\\ \\_\\ \\   /\\  ___\\   /\\  __-.  /\\ \\/ /")
print("\\ \\  _-/ \\ \\____ \\  \\ \\___  \\  \\ \\  __ \\  \\ \\___  \\  \\ \\ \\/\\ \\ \\ \\  _!-.")
print(" \\ \\_\\    \\/\\_____\\  \\/\\_____\\  \\ \\_\\ \\_\\  \\/\\_____\\  \\ \\____-  \\ \\_\\ \\_\\")
print("  \\/_/     \\/_____/   \\/_____/   \\/_/\\/_/   \\/_____/   \\/____/   \\/_/\\/_/ ")
print("\n")
time.sleep(3)
print("\033[33mMoving files...\033[0m")
shutil.move(os.path.join(SDK_COMPRESSED_DIRECTORY, "sdk.zip"), os.path.join(SDK_DIRECTORY, "sdk.zip"))
time.sleep(1)
print("\033[33mDecompressing files...\033[0m")
subprocess.run(["unzip", os.path.join(SDK_DIRECTORY, "sdk.zip"), "-d", SDK_DIRECTORY])
time.sleep(1)
os.chdir(os.path.join(os.getenv("HOME"), "pysh-v0.0.1"))
os.remove("sdk.zip")
if os.path.exists(SDK_COMPRESSED_DIRECTORY):
    try:
        shutil.rmtree(SDK_COMPRESSED_DIRECTORY)
    except Exception as e:
        subprocess.run(["notify-send", "PYSH.SDK had a problem while installing!"])
os.remove("install.sh")
print("\033[33mDone!\033[0m")
subprocess.run(["notify-send", "PYSH.SDK has been successfully installed!"])
