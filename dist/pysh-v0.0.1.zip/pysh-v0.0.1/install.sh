cd sdk
chmod -x decompress.py
python3 decompress.py
